let game={day:1,cash:5000,inventory:100,sentiment:50,regulation:20};
let travelProgress=0;

function playSound(id){const s=document.getElementById(id); if(s){s.currentTime=0; s.play();}}

function updateStats(){
    const statsDiv=document.getElementById("stats");
    statsDiv.innerHTML=`<p>Day: ${game.day}</p><p>Cash: $${game.cash}</p><p>Inventory: ${game.inventory}</p><p>Sentiment: ${game.sentiment}</p><p>Reg Risk: ${game.regulation}</p>`;
    statsDiv.classList.add("fade-in");
    setTimeout(()=>statsDiv.classList.remove("fade-in"),400);
}

const factions={
    business:{name:"Business Lobby",img:"img/faction_business.png"},
    consumer:{name:"Consumer Coalition",img:"img/faction_consumer.png"},
    regulator:{name:"Regulatory Council",img:"img/faction_regulator.png"}
};

function randomEvent(){
    const events=[{text:"Tariff imposed",choices:[{text:"Absorb cost",effect:()=>game.cash-=500},{text:"Raise prices",effect:()=>game.sentiment-=10}]},
    {text:"Supply delay",choices:[{text:"Buy domestic",effect:()=>game.cash-=700},{text:"Wait",effect:()=>game.inventory-=20}]}];
    return events[Math.floor(Math.random()*events.length)];
}

function playTurn(){
    updateStats();

    maybeStartMiniGame();

    const fBox=document.getElementById("factionBox");
    const f=Object.values(factions)[Math.floor(Math.random()*3)];
    document.getElementById("factionPortrait").src=f.img;
    document.getElementById("factionName").innerText=f.name;
    fBox.style.opacity=1;
    setTimeout(()=>fBox.style.opacity=0,1400);

    const eventObj=randomEvent();
    const eventDiv=document.getElementById("event");
    eventDiv.innerHTML=`<p>${eventObj.text}</p>`;
    eventDiv.classList.add("fade-in");
    setTimeout(()=>eventDiv.classList.remove("fade-in"),400);

    const choicesDiv=document.getElementById("choices");
    choicesDiv.innerHTML="";
    eventObj.choices.forEach(choice=>{
        const btn=document.createElement("button");
        btn.textContent=choice.text;
        btn.onclick=()=>{
            playSound("soundClick");
            choice.effect();
            endTurn();
        };
        choicesDiv.appendChild(btn);
    });
}

function endTurn(){
    document.getElementById("choices").innerHTML="";
    document.getElementById("event").innerHTML="<p>Decision applied.</p>";
    document.getElementById("nextBtn").style.display="block";
}

document.getElementById("nextBtn").onclick=()=>{
    document.getElementById("nextBtn").style.display="none";
    travelProgress+=30;
    document.getElementById("travelDot").style.transform=`translateX(${travelProgress}px)`;
    game.day++;
    playTurn();
};

document.getElementById("startGameBtn").onclick=()=>{
    playSound("soundClick");
    const t=document.getElementById("titleScreen");
    t.style.opacity=0;
    setTimeout(()=>t.style.display="none",700);
};

function openMiniGame(title){
    document.getElementById("miniGameTitle").innerText=title;
    document.getElementById("miniGameModal").style.display="flex";
}
function closeMiniGame(){
    document.getElementById("miniGameModal").style.display="none";
    document.getElementById("miniGameArea").innerHTML="";
}
document.getElementById("miniGameCloseBtn").onclick=closeMiniGame;

// Supply chain shuffle
function playSupplyChainShuffle(){
    openMiniGame("Supply Chain Shuffle");
    const area=document.getElementById("miniGameArea");
    const paths=["A","B","C"];
    const correct=paths[Math.floor(Math.random()*3)];
    area.innerHTML=`<p>Which route avoids delays?</p>
    <button class='supplyRouteBtn'>Route A</button>
    <button class='supplyRouteBtn'>Route B</button>
    <button class='supplyRouteBtn'>Route C</button>`;
    document.querySelectorAll(".supplyRouteBtn").forEach(btn=>{
        btn.onclick=()=>{
            if(btn.innerText.endsWith(correct)){
                game.inventory+=20; game.cash+=200; playSound("soundSuccess");
                area.innerHTML="<p>Correct!</p>";
            }else{
                game.inventory-=10; playSound("soundDanger");
                area.innerHTML="<p>Wrong route</p>";
            }
        };
    });
}

// Lobbying gamble
function playLobbyingGamble(){
    openMiniGame("Lobbying Gamble");
    const area=document.getElementById("miniGameArea");
    area.innerHTML=`<p>Pick lobbying strength</p>
    <button data-cost='200'>Low</button>
    <button data-cost='500'>Medium</button>
    <button data-cost='1000'>High</button>`;
    area.querySelectorAll("button").forEach(btn=>{
        btn.onclick=()=>{
            const cost=Number(btn.dataset.cost);
            game.cash-=cost;
            const chance=cost===200?0.3:cost===500?0.55:0.75;
            if(Math.random()<chance){
                game.sentiment+=10; playSound("soundSuccess");
                area.innerHTML="<p>Success!</p>";
            } else {
                game.regulation+=10; playSound("soundDanger");
                area.innerHTML="<p>Failed!</p>";
            }
        };
    });
}

// Forecast quick-draw
function playEconomicForecast(){
    openMiniGame("Economic Forecast");
    const area=document.getElementById("miniGameArea");
    area.innerHTML=`<p>Wait for signal</p><button id='forecastBtn' disabled>Wait...</button><p id='reactionText'></p>`;
    const btn=document.getElementById("forecastBtn");
    const text=document.getElementById("reactionText");
    const delay=Math.random()*2000+1000;
    setTimeout(()=>{
        btn.disabled=false; btn.innerText="Click!";
        const start=performance.now();
        btn.onclick=()=>{
            const ms=Math.round(performance.now()-start);
            if(ms<250){game.cash+=500; playSound("soundSuccess"); text.innerText="Excellent";}
            else if(ms<500){game.cash+=200; text.innerText="Decent";}
            else {game.cash-=300; playSound("soundDanger"); text.innerText="Slow";}
        };
    },delay);
}

function maybeStartMiniGame(){
    const r=Math.random();
    if(r<0.15)return playSupplyChainShuffle();
    if(r<0.25)return playLobbyingGamble();
    if(r<0.35)return playEconomicForecast();
}

playTurn();