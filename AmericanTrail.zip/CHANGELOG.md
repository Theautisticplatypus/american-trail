# Changelog

## Version 1.0.0 – Initial Release
- Added retro Oregon Trail themed UI
- Added USA map with travel nodes
- Implemented 20-event political and economic engine
- Added mini-games:
  - Supply Chain Shuffle
  - Lobbying Gamble
  - Political Forecast
- Added faction reaction system
- Added full win and fail conditions
- Added README, LICENSE, and GitHub workflow support
